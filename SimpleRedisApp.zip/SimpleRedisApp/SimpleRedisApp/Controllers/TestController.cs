﻿using Microsoft.AspNetCore.Mvc;
using SimpleRedisApp.Models;
using SimpleRedisApp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleRedisApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly ICacheServices _cacheService;
        public TestController(ICacheServices cacheService)
        {
            _cacheService = cacheService;
        }
        [HttpGet("AuthTest")]
        public string AuthTest()
        {
            //var UserId = GetUserId();
            return "Başarılı";
        }
        [HttpPost("Create")]

        public IActionResult Create([FromBody ]LoginModel loginInfo)
        {
            //var models = await _cacheService.GetAsync<List<TestModel>>("models") ?? new List<TestModel>();
            //var model = new TestModel(Faker.Name.First(), Faker.Name.Last());
            //models.Add(model);

            var result  = _cacheService.SetAsync("models", loginInfo);
            return Ok(loginInfo);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var models = await _cacheService.GetAsync<List<TestModel>>("models");
            if (models != null)
            {
                try
                {
                    var guidId = new Guid(id);
                    var model = models.FirstOrDefault(p => p.Id == guidId);
                    if (model != null)
                    {
                        return Ok(model);
                    }
                }
                catch (System.Exception)
                {
                }
            }
            return BadRequest("Üye bulunamadı");
        }

        [HttpGet("Get")]
        public async Task<IActionResult> Get()
        {

            var cache = await _cacheService.GetAsync<LoginModel>("models");

            return Ok(cache);
        }
    }
}
