﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleRedisApp.Models
{
    public class LoginModel
    {
        public string Token { get; set; }
        public decimal? BranchId { get; set; }
    }
}
